package Cards;

public enum CardsSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
