package harvestingFields;

public enum Commands {
    //public, private, protected, all
    PUBLIC, PRIVATE, PROTECTED, ALL
}
