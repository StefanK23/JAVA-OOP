package Vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens = scanner.nextLine().split("\\s+");

        Vehicle car = new Car(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]));


        tokens = scanner.nextLine().split("\\s+");

        Vehicle truck = new Truck(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]));

        int commandsCOunt = Integer.parseInt(scanner.nextLine());

        while (commandsCOunt-- > 0) {
            String[] params = scanner.nextLine().split("\\s+");
            double argument = Double.parseDouble(tokens[2]);
            String command = scanner.nextLine();

            if (command.contains("Drive")) {
                if (params[1].equals("Car")) {
                    System.out.println(car.drive(argument));
                } else {
                    System.out.println(truck.drive(argument));
                }
            } else {
                if (params[1].equals("Car")) {
                    car.refuel(argument);
                }else{
                    truck.refuel(argument);
                }
            }
        }
        System.out.println(car.toString());
        System.out.println(truck.toString());
    }
}
