package vehicles;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Truck extends Vehicle {

    public Truck(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm);
    }

    @Override
    void drive(double distance) {
        double litersPerKm = super.getLitersPerKm() + 1.6;
        double updatedFuelQuantity = super.getFuelQuantity() - (litersPerKm * distance);

        if (updatedFuelQuantity >= 0) {
            super.setFuelQuantity(super.getFuelQuantity() - (litersPerKm * distance));

            DecimalFormat decimalFormat = new DecimalFormat("##.##");
            System.out.printf("Truck travelled %s km%n", decimalFormat.format(distance));
        } else {
            System.out.println("Truck needs refueling");
        }

    }

    @Override
    void refuel(double liters) {
        liters *= 0.95;
        super.setFuelQuantity(super.getFuelQuantity() + liters);
    }
}
