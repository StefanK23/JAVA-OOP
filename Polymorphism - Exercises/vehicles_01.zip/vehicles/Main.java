package vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] carInfo = readStringArray(scanner);
        String[] truckInfo = readStringArray(scanner);

        Vehicle car = new Car(Double.parseDouble(carInfo[1]), Double.parseDouble(carInfo[2]));
        Vehicle truck = new Truck(Double.parseDouble(truckInfo[1]), Double.parseDouble(truckInfo[2]));

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n; i++) {
            String[] commands = readStringArray(scanner);
            String command = commands[0];
            String vehicleType = commands[1];


            switch (command) {
                case "Drive":
                    double distance = Double.parseDouble(commands[2]);
                    driveVehicle(car, truck, vehicleType, distance);
                    break;
                case "Refuel":
                    double liters = Double.parseDouble(commands[2]);
                    refuelVehicle(car, truck, vehicleType, liters);
                    break;
            }
        }

        System.out.printf("Car: %.2f%n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f", truck.getFuelQuantity());
    }

    private static void refuelVehicle(Vehicle car, Vehicle truck, String vehicleType, double liters) {
        if (vehicleType.equals("Car")) {
            car.refuel(liters);
            return;
        }
        truck.refuel(liters);
    }

    private static void driveVehicle(Vehicle car, Vehicle truck, String vehicle, double distance) {
        if (vehicle.equals("Car")) {
            car.drive(distance);
            return;
        }
        truck.drive(distance);
    }

    private static String[] readStringArray(Scanner scanner) {
        return scanner.nextLine().split("\\s+");
    }
}
