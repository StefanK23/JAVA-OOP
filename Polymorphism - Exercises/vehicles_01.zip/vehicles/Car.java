package vehicles;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Car extends Vehicle {

    public Car(double fuelQuantity, double litersPerKm) {
        super(fuelQuantity, litersPerKm);
    }

    @Override
    void drive(double distance) {
        double litersPerKm = super.getLitersPerKm() + 0.9;
        double updatedFuelQuantity = super.getFuelQuantity() - (litersPerKm * distance);
        if (updatedFuelQuantity >= 0) {
            super.setFuelQuantity(super.getFuelQuantity() - (litersPerKm * distance));

            DecimalFormat decimalFormat = new DecimalFormat("##.##");
            System.out.printf("Car travelled %s km%n", decimalFormat.format(distance));
        } else {
            System.out.println("Car needs refueling");
        }
    }

    @Override
    void refuel(double liters) {
        super.setFuelQuantity(super.getFuelQuantity() + liters);
    }
}
