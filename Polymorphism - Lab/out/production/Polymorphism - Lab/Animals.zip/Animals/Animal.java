package Animals;

public abstract class Animal {


    public abstract String explainSelf();


}
