package Animals;

public class Cat extends Animal{
           private  String name;
           private String favoriteFood;

    public Cat(String name, String favoriteFood) {
        this.name = name;
        this.favoriteFood = favoriteFood;
    }

    @Override
    public String explainSelf() {
        return  String.format("I am %s and my favourite food is %s%n" +
                "MEEOW",name, favoriteFood);
    }
}
