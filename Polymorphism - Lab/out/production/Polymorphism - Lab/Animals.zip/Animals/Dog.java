package Animals;

public class Dog extends Animal{
    private  String name;
    private String favoriteFood;

    public Dog(String name, String favoriteFood) {
        this.name = name;
        this.favoriteFood = favoriteFood;
    }
    @Override
    public String explainSelf() {
        return String.format("I am %s and my favourite food is %s%n" +
                "DJAAF", name, favoriteFood);

    }
}
