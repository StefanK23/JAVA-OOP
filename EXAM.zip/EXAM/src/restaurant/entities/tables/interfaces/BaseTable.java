package restaurant.entities.tables.interfaces;

import restaurant.common.ExceptionMessages;
import restaurant.entities.drinks.interfaces.BaseBeverage;
import restaurant.entities.drinks.interfaces.Beverages;
import restaurant.entities.healthyFoods.interfaces.HealthyFood;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BaseTable implements Table{

    private List<HealthyFood> healthyFood;
    private List<Beverages> beverages;
    private int number;
    private int size;
    private int numberOfPeople;
    private double pricePerPerson; //price per person on the table;
    private boolean isReservedTable;
    private double allPeople; //price for all people


    public BaseTable(int number, int size, double pricePerPerson) {
        this.number = number;
        this.setSize(size);
        this.pricePerPerson = pricePerPerson;
        healthyFood = new ArrayList<>();
        beverages = new ArrayList<>();
        this.setNumberOfPeople(numberOfPeople);
    }


    public void setSize(int size) {
        if(size < 0) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_TABLE_SIZE);
        }
        this.size = size;
    }

    public void setNumberOfPeople(int numberOfPeople) {
        if(numberOfPeople <= 0 ){
            throw new IllegalArgumentException(ExceptionMessages.INVALID_NUMBER_OF_PEOPLE);
        }
        this.numberOfPeople = numberOfPeople;
    }

    @Override
    public int getTableNumber() {
        return number;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public int numberOfPeople() {
        return numberOfPeople;
    }

    @Override
    public double pricePerPerson() {
        return pricePerPerson;
    }

    @Override
    public boolean isReservedTable() {
        return isReservedTable = true;
    }

    @Override
    public double allPeople() {
        return allPeople;
    }

    @Override
    public void reserve(int numberOfPeople) {
        this.numberOfPeople = numberOfPeople;
    }

    @Override
    public void orderHealthy(HealthyFood food) {
          healthyFood.add(food);
    }

    @Override
    public void orderBeverages(Beverages beverage) {
           beverages.add(beverage);
    }

    @Override
    public double bill() {
      double bill =   healthyFood.stream().mapToDouble(HealthyFood::getPrice).sum()
                + beverages.stream().mapToDouble(Beverages::getPrice).sum();

        return bill;
    }

    @Override
    public void clear() {
        healthyFood.clear();
        beverages.clear();
        isReservedTable = false;
        setNumberOfPeople(0);
        setPricePerPerson(0);

    }

    public void setPricePerPerson(double pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    @Override
    public String tableInformation() {
        return String.format("Table - %d" +
                "Size - %d" +
                "Type - %s" +
                "All price - %f",this.number,this.size,this.isReservedTable,this.pricePerPerson);
    }
}
