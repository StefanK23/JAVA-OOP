package restaurant.repositories.interfaces;

import restaurant.entities.drinks.interfaces.Beverages;

import java.util.*;

public class BeverageRepositoryImpl implements BeverageRepository<Beverages>{

    List<Beverages> beverages;

    public BeverageRepositoryImpl(){
        this.beverages = new ArrayList<>();
    }


    @Override
    public Beverages beverageByName(String drinkName, String drinkBrand) {
        // return   healthyFoods.stream().filter(a -> a.getName().equals(name)).findFirst().orElse(null);

        return beverages.stream().filter(a -> a.getName().equals(drinkName)).findFirst().orElse(null);
    }

    @Override
    public Collection<Beverages> entities() {
        return entities();
    }

    @Override
    public Collection<Beverages> getAllEntities() {


        return Collections.unmodifiableList(beverages);
    }

    @Override
    public void add(Beverages entity) {
        this.beverages.add(entity);
    }
}
