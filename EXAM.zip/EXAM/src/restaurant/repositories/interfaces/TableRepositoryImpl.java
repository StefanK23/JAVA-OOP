package restaurant.repositories.interfaces;

import restaurant.entities.tables.interfaces.Table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class TableRepositoryImpl implements TableRepository<Table>{

    List<Table> tables;

    public TableRepositoryImpl() {
           this.tables = new ArrayList<>();
    }


    @Override
    public Collection<Table> entities() {
        return entities();
    }

    @Override
    public Collection<Table> getAllEntities() {
        return Collections.unmodifiableList(tables);
    }

    @Override
    public void add(Table entity) {
        this.tables.add(entity);
    }

    @Override
    public Table byNumber(int number) {


          return tables.stream().filter((table) -> {
            return table.getTableNumber() == number;
        }).findFirst().orElse(null);

    }
}
