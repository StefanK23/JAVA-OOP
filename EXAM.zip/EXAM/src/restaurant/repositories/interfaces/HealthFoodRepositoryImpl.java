package restaurant.repositories.interfaces;

import restaurant.entities.healthyFoods.interfaces.HealthyFood;

import java.util.*;

public class HealthFoodRepositoryImpl implements HealthFoodRepository<HealthyFood> {

    List<HealthyFood> healthyFoods;

    public HealthFoodRepositoryImpl() {
        this.healthyFoods = new ArrayList<>();
    }

    @Override
    public HealthyFood foodByName(String name) {
       return   healthyFoods.stream().filter(a -> a.getName().equals(name)).findFirst().orElse(null);

    }

    @Override
    public Collection<HealthyFood> entities() {
        return entities();
    }

    @Override
    public Collection<HealthyFood> getAllEntities() {
        return Collections.unmodifiableList(healthyFoods);
    }

    @Override
    public void add(HealthyFood entity) {
          healthyFoods.add(entity);
    }
}
