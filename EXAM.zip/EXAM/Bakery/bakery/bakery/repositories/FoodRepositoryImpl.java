package bakery.repositories;

import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.tables.interfaces.Table;
import bakery.repositories.interfaces.FoodRepository;

import java.util.*;

public class FoodRepositoryImpl implements FoodRepository<BakedFood> {
    private Map<String, BakedFood> models;

    public FoodRepositoryImpl() {
        this.models = new LinkedHashMap<>();
    }

    @Override
    public BakedFood getByName(String name) {
        return this.models.get(name);
    }

    @Override
    public Collection<BakedFood> getAll() {
        return Collections.unmodifiableCollection(this.models.values());
    }

    @Override
    public void add(BakedFood food) {
        this.models.put(food.getName(), food);
    }
}
