package MultipleImplemtation;

public interface Identifiable {
    String getId();
}
