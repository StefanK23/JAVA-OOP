package MultipleImplemtation;

public interface Birthable {
    String getBirthDate();
}
