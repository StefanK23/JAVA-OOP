package MultipleImplemtation;

public interface Person {
    String getName();
    int getAge();
}
